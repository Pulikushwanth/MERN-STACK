import React, { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import Card from "../components/Card";

export default function Products() {
  const [search, setSearch] = useState("");
  const [foodCat, setFoodCat] = useState([]);
  const [foodItem, setFoodItem] = useState([]);

  const loadData = async () => {
    let response = await fetch("http://localhost:5001/api/foodData", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });
    response = await response.json();
    setFoodItem(response[0]);
    setFoodCat(response[1]);
  };

  useEffect(() => {
    loadData();
  }, []);

  // Check if there are no results across any category
  const getFilteredItems = () => {
    return foodCat.map((data) => {
      return foodItem.filter(
        (item) =>
          item.CategoryName === data.CategoryName &&
          item.name.toLowerCase().includes(search.toLowerCase())
      );
    });
  };

  const filteredItems = getFilteredItems();
  const hasNoResults = filteredItems.every((categoryItems) => categoryItems.length === 0) && search.length > 0;

  return (
    <div>
      {/* Navbar */}
      <Navbar />

      {/* Spacer to push content below fixed Navbar */}
      <div style={{ height: "120px" }}></div>

      {/* Search Bar */}
      <div className="container mb-4 ">
        <div className="d-flex justify-content-center">
          <input
            className="form-control w-50"
            type="search"
            placeholder="Search Food Item..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              padding: "0.75rem 1rem",
              
              borderRadius: "8px",
              border: "2px solid #4caf50",
              boxShadow: "0 2px 6px rgba(0, 0, 0, 0.1)",
              fontSize: "1rem",
            }}
          />
        </div>
      </div>

      {/* Food Categories and Cards */}
      <div className="container">
        {foodCat.map((data) => {
          const filteredItemsInCategory = filteredItems.find(
            (item) => item.length > 0 && item[0].CategoryName === data.CategoryName
          );

          return (
            <div className="row mb-3" key={data._id}>
              {filteredItemsInCategory && (
                <>
                  <div className="fs-3 m-3">{data.CategoryName}</div>
                  <hr />
                  {filteredItemsInCategory.map((filterItems) => (
                    <div
                      key={filterItems._id}
                      className="col-12 col-md-6 col-lg-3 mb-3"
                    >
                      <Card
                        foodItem={filterItems}
                        options={filterItems.options[0]}
                      />
                    </div>
                  ))}
                </>
              )}
            </div>
          );
        })}

        {/* Display No Results Matched Message if no matches found */}
        {hasNoResults && (
          <div className="col-12 text-center text-danger fs-4">
            No Match Found
          </div>
        )}
      </div>

      {/* Footer */}
      <Footer />
    </div>
  );
}
