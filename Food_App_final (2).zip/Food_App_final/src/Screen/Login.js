import { useState } from "react";
import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { Alert, Button, Form } from "react-bootstrap";

export default function Login() {
  const [credentials, setcredentials] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  let navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(credentials.email)) {
      setError("Invalid email format");
      return;
    }

    try {
      const response = await fetch("http://localhost:5000/api/loginuser", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: credentials.email,
          password: credentials.password,
        }),
      });
      const json = await response.json();

      if (!json.success) {
        setError("Invalid credentials. Please try again.");
      } else {
        localStorage.setItem("userEmail", credentials.email);
        localStorage.setItem("authToken", json.authToken);
        alert("Login Successful");
        navigate("/"); // Redirect to home page after successful login
      }
    } catch (err) {
      setError("Error connecting to the server.");
    }
  };

  const onChange = (event) => {
    setcredentials({ ...credentials, [event.target.name]: event.target.value });
  };
  const inputStyle = {
    borderRadius: "8px",
    padding: "10px",
    border: "2px solid #ccc",
    transition: "border-color 0.3s, box-shadow 0.3s",
  };

  const inputFocusStyle = {
    borderColor: "#1b5e20",
    boxShadow: "0 0 5px rgba(27, 94, 32, 0.5)",
  };
  return (
    <div
      className="d-flex justify-content-center align-items-center vh-100"
      style={{
        background: "linear-gradient(to right, #a5d6a7, #81c784)", // Light green gradient
      }}
    >
      <div
        className="p-4"
        style={{
          width: "100%",
          maxWidth: "400px",
          borderRadius: "12px",
          boxShadow: "0 6px 15px rgba(0, 0, 0, 0.1)",
          backgroundColor: "#fff", // White background for the form container
        }}
      >
        <h2 className="text-center mb-4" style={{ color: "#388e3c" }}>
          Login
        </h2>

        {error && <Alert variant="danger">{error}</Alert>}

        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3" controlId="formEmail">
            <Form.Label>Email Address</Form.Label>
            <Form.Control
              type="email"
              placeholder="Enter email"
              name="email"
              value={credentials.email}
              onChange={onChange}
              style={{
                borderRadius: "8px",
                padding: "10px",
                borderColor: "#388e3c",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                transition: "0.3s",
              }}
              
              onFocus={(e) => Object.assign(e.target.style, inputFocusStyle)}
              onBlur={(e) => Object.assign(e.target.style, inputStyle)}
            />
          </Form.Group>

          <Form.Group className="mb-3" controlId="formPassword">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Enter password"
              name="password"
              value={credentials.password}
              onChange={onChange}
              style={{
                borderRadius: "8px",
                padding: "10px",
                borderColor: "#388e3c",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                transition: "0.3s",
              }}
              
              onFocus={(e) => Object.assign(e.target.style, inputFocusStyle)}
              onBlur={(e) => Object.assign(e.target.style, inputStyle)}
            />
          </Form.Group>

          <Button
            variant="success"
            type="submit"
            className="w-100"
            style={{
              backgroundColor: "#388e3c", // Green color for the button
              borderColor: "#388e3c",
              borderRadius: "25px",
              padding: "12px 20px",
              fontWeight: "bold",
              transition: "background-color 0.3s ease",
            }}
            onMouseOver={(e) => (e.target.style.backgroundColor = "#2c6e1f")} // Darker on hover
            onMouseOut={(e) => (e.target.style.backgroundColor = "#388e3c")} // Back to original color
          >
            Login
          </Button>
        </Form>

        <div className="mt-3 text-center">
          {/* Fix the link with correct styling */}
          <Link to="/creatuser">
            <Button
              variant="danger"
              className="w-100 mt-3"
              style={{
                backgroundColor: "#d32f2f", // Red background color
                borderColor: "#d32f2f", 
                borderRadius: "25px",
                padding: "12px 20px",
                fontWeight: "bold",
                transition: "background-color 0.3s ease",
              }}
              onMouseOver={(e) => (e.target.style.backgroundColor = "#9a0007")}
              onMouseOut={(e) => (e.target.style.backgroundColor = "#d32f2f")}
            >
              I am a new user
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
