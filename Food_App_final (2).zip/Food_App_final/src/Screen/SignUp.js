import React, { useState } from "react";
import { Form, Button, Alert } from "react-bootstrap";
import { useNavigate, Link } from "react-router-dom";

const Signup = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [address, setAddress] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSignup = async (e) => {
    e.preventDefault();

    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError("Invalid email format");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    if (password.length < 4) {
      setError("Password must be at least 4 characters long");
      return;
    }

    setError("");

    try {
      const response = await fetch("http://localhost:5000/api/creatuser", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name,
          email,
          password,
          location: address,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        alert("Signup Successful");
        navigate("/login");
      } else {
        if (data.message === "User already exist") {
          setError("This email is already used");
        } else {
          setError(data.message || data.error || "Signup failed");
        }
      }
    } catch (err) {
      console.error("Signup error:", err);
      setError("Error connecting to the server.");
    }
  };

  const inputStyle = {
    borderRadius: "8px",
    padding: "10px",
    border: "2px solid #ccc",
    transition: "border-color 0.3s, box-shadow 0.3s",
    minHeight: "40px", // Ensures the height consistency for inputs
  };

  const inputFocusStyle = {
    borderColor: "#1b5e20",
    boxShadow: "0 0 5px rgba(27, 94, 32, 0.5)",
  };

  return (
    <div
      className="d-flex justify-content-center align-items-center"
      style={{
        minHeight: "100vh",
        background: "linear-gradient(to right, #c8e6c9, #a5d6a7)",
        padding: "20px", // Padding to prevent form overflow on small screens
      }}
    >
      <div
        className="p-4"
        style={{
          width: "100%",
          maxWidth: "400px",
          borderRadius: "12px",
          boxShadow: "0 6px 15px rgba(0, 0, 0, 0.1)",
          backgroundColor: "#fff",
          maxHeight: "90vh", // Prevents overflow
          overflowY: "auto", // Adds scroll inside, if needed
        }}
      >
        <h2 className="text-center mb-4" style={{ color: "#388e3c" }}>
          Signup
        </h2>

        {error && <Alert variant="danger">{error}</Alert>}

        <Form onSubmit={handleSignup}>
          <Form.Group className="mb-3">
            <Form.Label>Name</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              style={inputStyle}
              onFocus={(e) => Object.assign(e.target.style, inputFocusStyle)}
              onBlur={(e) => Object.assign(e.target.style, inputStyle)}
            />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Email address</Form.Label>
            <Form.Control
              type="email"
              placeholder="Enter email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={inputStyle}
              onFocus={(e) => Object.assign(e.target.style, inputFocusStyle)}
              onBlur={(e) => Object.assign(e.target.style, inputStyle)}
            />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={inputStyle}
              onFocus={(e) => Object.assign(e.target.style, inputFocusStyle)}
              onBlur={(e) => Object.assign(e.target.style, inputStyle)}
            />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Confirm Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Confirm Password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              style={inputStyle}
              onFocus={(e) => Object.assign(e.target.style, inputFocusStyle)}
              onBlur={(e) => Object.assign(e.target.style, inputStyle)}
            />
          </Form.Group>
{/* 
          <Form.Group className="mb-3">
            <Form.Label>Address</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter your address"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              style={inputStyle}
              onFocus={(e) => Object.assign(e.target.style, inputFocusStyle)}
              onBlur={(e) => Object.assign(e.target.style, inputStyle)}
            />
          </Form.Group> */}

          <Button
            variant="success"
            type="submit"
            className="w-100"
            style={{
              backgroundColor: "#388e3c",
              borderColor: "#388e3c",
              borderRadius: "25px",
              padding: "12px 20px",
              fontWeight: "bold",
            }}
          >
            Signup
          </Button>
        </Form>

        <div className="mt-3 text-center">
          <Link to="/login">
            <Button
              variant="danger"
              className="w-100 mt-3"
              style={{
                borderRadius: "25px",
                padding: "12px 20px",
                fontWeight: "bold",
              }}
            >
              Already a User? Login
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Signup;
