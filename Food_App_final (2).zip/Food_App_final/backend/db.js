const mongoose = require("mongoose");
const mongoURI ="mongodb+srv://test:test@cluster0.oegwxzv.mongodb.net/Tasty_Heaven";
const mongoDB = async () => {
  try{
    await mongoose.connect(mongoURI, { useNewUrlParser: true });
   
      console.log("DB Connected Successfully");
      const fetched_data=await mongoose.connection.db.collection("foodData");
      
      try{
        const data=await fetched_data.find({}).toArray();
        const foodCategory=await mongoose.connection.db.collection("foodCategory");
        try {
          const catData= await foodCategory.find({}).toArray();
          global.food_items=data;

          global.foodCategory=catData;

        } catch (err) {
          console.log(err);
        }
         

          

      }catch(err){
        console.log(err.message);
      }
  }
  catch(err){
    console.log(err);
  };
}
  
    
module.exports = mongoDB;
